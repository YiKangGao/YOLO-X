import torch

print(torch.__version__)

print(torch.version.cuda)

print(torch.backends.cudnn.version())

